---
name: claude-code-best-practices
description: Boas práticas para maximizar qualidade de código, economizar tokens e usar agentes/skills no Claude Code. Baseado no vazamento do código-fonte interno + arquitetura real do sistema.
triggers:
  - "como melhorar o código gerado"
  - "boas práticas claude code"
  - "economizar tokens"
  - "qualidade de código"
  - "usar agente"
  - "otimizar claude code"
---

# Boas Práticas — Claude Code

Guia derivado da arquitetura interna real do Claude Code para maximizar qualidade, economizar tokens e aproveitar o modo agente.

---

## PARTE 1 — Qualidade do Código Gerado

### 1. Contexto antes de pedir código
Sempre informe: stack exato, versões, padrões já usados no projeto, restrições.

Ruim: "cria uma função de login"
Bom: "Next.js 14 App Router, JWT, PostgreSQL + Prisma — cria login que valida email/senha e retorna token com expiração 24h"

### 2. PLAN antes de implementar
Antes de código complexo, peça o plano primeiro:
"Antes de implementar, me dá um plano passo a passo do que vai fazer."

O Claude Code tem modo interno de planejamento (PLAN mode) — ativá-lo reduz retrabalho.

### 3. Revisão em turno separado
Primeiro implemente. Depois em mensagem separada:
"Revise o código que gerou — identifique bugs, edge cases não tratados e melhorias."

O modelo critica o próprio output muito melhor em turno separado.

### 4. Ancoragem em código existente
Cole um exemplo do projeto como referência:
"Segue o endpoint de criação de usuário. Cria o de atualização seguindo exatamente o mesmo padrão."

### 5. Especifique o que NÃO quer
"Não use useEffect para fetch, use React Query. Não crie novos tipos, use os de types/index.ts."

### 6. TDD como guia
1. "Escreve os testes unitários para essa função"
2. "Agora implementa para os testes passarem"

Código gerado nesse fluxo tem menos bugs e edge cases ignorados.

---

## PARTE 2 — Economia de Tokens

### 1. Referencie arquivos, não cole conteúdo
Ruim: colar 300 linhas no chat
Bom: "olhando src/auth/middleware.ts, adiciona rate limiting"

O agente lê arquivos diretamente. Colar consome contexto desnecessário.

### 2. Sessões curtas e focadas
Conversas longas degradam qualidade — o modelo começa a "esquecer" o início. Quebre tarefas grandes em sessões por funcionalidade.

### 3. Descreva o estado final, não iterações
Ruim: "melhora um pouco mais" (cada turno gasta tokens sem clareza)
Bom: "refatora para: (1) extrair validação para helper, (2) early return em vez de else aninhado, (3) JSDoc"

### 4. Use o padrão [SILENT] interno
O agente tem mecanismo interno de supressão quando não há nada novo. Replique isso:
"Se o código já estiver correto, responda só OK. Não explique o que está certo."

### 5. Batche tarefas relacionadas
Em vez de 5 mensagens para 5 arquivos:
"Nos arquivos user.service.ts, auth.service.ts e email.service.ts: adiciona tratamento de erro com AppError"

### 6. Memória persistente para contexto fixo
Peça para salvar convenções do projeto em memória. Elimina reexplicar o stack a cada sessão.

---

## PARTE 3 — Agente e Skills

### 1. Objetivos, não instruções passo a passo
Chat: "abre X, lê, faz Y, depois Z..." (microgerenciamento)
Agente: "implementa exportação de PDF no módulo de relatórios. Testes devem passar ao final."

### 2. Skills = memória procedimental
Skills ensinam o agente como fazer tarefas repetidas. Crie para:
- Convenções do projeto (nomenclatura, estrutura de pastas)
- Fluxo de deploy
- Como rodar testes
- Padrões de código do time

Criar: "salva esse processo como skill chamada [nome]"

### 3. Subagentes para tarefas paralelas
O agente pode delegar para subagentes isolados em paralelo:
- Refatorar múltiplos módulos ao mesmo tempo
- Pesquisar e implementar simultaneamente
- Revisar enquanto implementa outra feature

"Divide essa tarefa em partes independentes e executa em paralelo."

### 3.1 Roteamento de modelo nos subagentes (REGRA)
**Foco: qualidade do output.** Ao despachar via tool `Agent`, sempre passar `model` explícito:

- **Sonnet** — busca, exploração, leitura, varredura, coleta de dados (`Explore`, `general-purpose` em modo investigativo, `claude-code-guide`). Sonnet é mais que suficiente pra navegar código e responder "o que tem onde".
- **Opus** — análise, refactor, implementação, escrita de código, revisão. Tudo que produz ou modifica código vai pra Opus, sem exceção.

Nunca delegar código (refactor/implementação/análise) pra Sonnet, e nunca queimar Opus em tarefa puramente investigativa.

### 4. Contexto de sessão vs memória persistente
- Sessão: sabe enquanto a conversa está aberta
- Memória: volta em toda sessão futura

Salvar em memória: convenções do projeto, stack, preferências de código.

### 5. Crons como agentes autônomos
Arquitetura interna: crons são agentes completos rodando sem o usuário. Use para:
- Rodar testes diariamente e avisar se quebrou
- Monitorar PRs e resumir o que precisa atenção
- Code review automático de commits novos

### 6. Ciclo ideal para tarefas complexas
```
1. você  → "analisa o problema e me dá um plano"
2. você  → revisa o plano
3. você  → "executa o plano"
4. agente → trabalha autonomamente
5. você  → "revisa e lista o que precisa ajuste"
```

---

## Resumo Rápido

| Objetivo | Prática-chave |
|---|---|
| Qualidade | Contexto de stack + TDD + revisão em turno separado |
| Tokens | Referenciar arquivos + sessões focadas + batching |
| Agente | Objetivos > instruções + skills para repetição + subagentes |

@RTK.md
